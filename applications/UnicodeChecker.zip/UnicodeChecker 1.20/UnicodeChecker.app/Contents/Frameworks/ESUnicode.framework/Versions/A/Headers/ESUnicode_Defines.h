//
//  ESUnicode_Defines.h
//  ESUnicode
//
//  Created by Steffen Kamp on 07.08.05.
//  Copyright 2005 earthlingsoft. All rights reserved.
//

#if !defined(ESUNICODE_EXPORT)
#define ESUNICODE_EXPORT extern
#endif
