//
//  UCDecInput.h
//  UnicodeChecker
//
//  Created by Steffen Kamp on 21.04.05.
//  Copyright 2005 earthlingsoft. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import "UCInput.h"


@interface UCDecInput : NSObject <UCInput> {

}

@end
